﻿
namespace SIGEM_TAEX.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    using System.Linq;
    using System.Security.Cryptography.X509Certificates;
    using System.Web;
    using System.Data.Entity.Validation;
    using System.IO;
    using System.Data.Entity;

    using SIGEM_TAEX.Filters;

    [Table("UsuarioDocente")]
    public class Usuariodocente
    {
        [Key]
        public int ID_UsuarioDocente { get; set; }

        public int ID_Docente { get; set; }

        [StringLength(50)]
        public string Nombre { get; set; }

        [StringLength(50)]
        public string Contraseña { get; set; }

        [StringLength(10)]
        public string Estado { get; set; }

        public virtual Docente Docente { get; set; }


        public static int id_docente_temporal = 0;
        public static string nombre_tempora_docente = "";


        public ResponseModel Acceder(string Usuario, string Password)
        {
            id_docente_temporal = ID_Docente;
            nombre_tempora_docente = Nombre;

            var rm = new ResponseModel();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    //Password = HashHelper.MD5(Password);
                    var query = db.Usuariodocente.Where(x => x.Nombre == Usuario)
                                    .Where(x => x.Contraseña == Password)
                                    .Where(x => x.Estado == "A")
                                    .SingleOrDefault();
                    if (query != null)
                    {
                        SessionHelper.AddUserToSession(query.ID_UsuarioDocente.ToString());
                        rm.SetResponse(true);
                    }
                    else
                    {
                        rm.SetResponse(false, "Usuario y/o password incorrectos");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return rm;
        }
        //Metodo Listar
        public List<Usuariodocente> Listar() //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<Usuariodocente>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.Usuariodocente.Include("Docente").ToList(); //Debe listar lo que hay en mi Tabla Usuario
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //Metodo Buscar
        public List<Usuariodocente> Buscar(String Criterio) //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<Usuariodocente>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.Usuariodocente.Include("Docente")
                                    .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios;
        }

        //Metodo Obtener

        public Usuariodocente Obtener(int id) //retornar un objeto
        {
            var obj_usuarios = new Usuariodocente();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.Usuariodocente.Include("Docente")
                                    .Where(x => x.ID_UsuarioDocente == id)
                                    .SingleOrDefault(); //devuelve un registro
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //metodo guardar
        public void Guardar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {
                    if (this.ID_UsuarioDocente > 0)
                    {
                        db.Entry(this).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Entry(this).State = EntityState.Added;
                    }
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //eliminar
        public void Eliminar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {


                    db.Entry(this).State = EntityState.Deleted;

                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        //Metodo de Perfil de usuario
        public ResponseModel GuardarPerfil()
        {
            var rm = new ResponseModel();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    db.Configuration.ValidateOnSaveEnabled = false;
                    var Usu = db.Entry(this);
                    Usu.State = EntityState.Modified;

                    if (this.ID_UsuarioDocente == 0) Usu.Property(x => x.ID_UsuarioDocente).IsModified = false;
                    if (this.ID_Docente == 0) Usu.Property(x => x.ID_Docente).IsModified = false;
                    if (this.Nombre == null) Usu.Property(x => x.Nombre).IsModified = false;
                    if (this.Contraseña == null) Usu.Property(x => x.Contraseña).IsModified = false;
                    if (this.Estado == null) Usu.Property(x => x.Estado).IsModified = false;

                    db.SaveChanges();
                    rm.SetResponse(true);
                }
            }
            catch (DbEntityValidationException e)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return rm;
        }
    }
}