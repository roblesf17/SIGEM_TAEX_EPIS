﻿

namespace SIGEM_TAEX.Models
{

    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    using System.Linq;
    using System.Security.Cryptography.X509Certificates;

    using System.Data.Entity.Validation;
    using System.IO;
    using System.Data.Entity;

    using SIGEM_TAEX.Filters;

    [Table("UsuarioOBUN")]

    public class UsuarioOBUN
    {
        [Key]
        public int ID_UsuarioObun { get; set; }

        public int ID_Personal { get; set; }

        [StringLength(50)]
        public string Nombre { get; set; }

        [StringLength(50)]
        public string Contraseña { get; set; }

        [StringLength(10)]
        public string Estado { get; set; }

        public virtual Personal_OBUN Personal_OBUN { get; set; }

        //Metodo Listar
        public List<UsuarioOBUN> Listar() //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<UsuarioOBUN>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioOBUN.Include("Personal_OBUN").ToList(); //Debe listar lo que hay en mi Tabla Usuario
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //Metodo Buscar

        public List<UsuarioOBUN> Buscar(String Criterio) //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<UsuarioOBUN>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioOBUN.Include("Personal_OBUN")
                                    .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios;
        }

        //Metodo Obtener
        public UsuarioOBUN Obtener(int id) //retornar un objeto
        {
            var obj_usuarios = new UsuarioOBUN();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioOBUN.Include("Personal_OBUN")
                                    .Where(x => x.ID_UsuarioObun == id)
                                    .SingleOrDefault(); //devuelve un registro
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //metodo guardar
        public void Guardar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {
                    if (this.ID_UsuarioObun > 0)
                    {
                        db.Entry(this).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Entry(this).State = EntityState.Added;
                    }
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //eliminar
        public void Eliminar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {


                    db.Entry(this).State = EntityState.Deleted;

                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public ResponseModel Acceder(string Usuario, string Password)
        {
            var rm = new ResponseModel();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    //Password = HashHelper.MD5(Password);
                    var query = db.UsuarioOBUN.Where(x => x.Nombre == Usuario)
                                    .Where(x => x.Contraseña == Password)
                                    .Where(x=>x.Estado=="A")
                                    .SingleOrDefault();
                    if (query != null)
                    {
                        SessionHelper.AddUserToSession(query.ID_UsuarioObun.ToString());
                        rm.SetResponse(true);
                    }
                    else
                    {
                        rm.SetResponse(false, "Usuario y/o password incorrectos");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return rm;
        }
        public ResponseModel GuardarPerfil()
        {
            var rm = new ResponseModel();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    db.Configuration.ValidateOnSaveEnabled = false;
                    var Usu = db.Entry(this);
                    Usu.State = EntityState.Modified;

                    if (this.ID_UsuarioObun == 0) Usu.Property(x => x.ID_UsuarioObun).IsModified = false;
                    if (this.ID_Personal == 0) Usu.Property(x => x.ID_Personal).IsModified = false;
                    if (this.Nombre == null) Usu.Property(x => x.Nombre).IsModified = false;
                    if (this.Contraseña == null) Usu.Property(x => x.Contraseña).IsModified = false;
                    if (this.Estado == null) Usu.Property(x => x.Estado).IsModified = false;

                    db.SaveChanges();
                    rm.SetResponse(true);
                }
            }
            catch (DbEntityValidationException e)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return rm;
        }
    }
}