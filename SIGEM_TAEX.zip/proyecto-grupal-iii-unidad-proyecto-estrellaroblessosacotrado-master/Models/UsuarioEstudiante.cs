﻿

namespace SIGEM_TAEX.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    using System.Linq;
    using System.Security.Cryptography.X509Certificates;

    using System.Data.Entity.Validation;
    using System.IO;
    using System.Data.Entity;

    using SIGEM_TAEX.Filters;

    [Table("UsuarioEstudiante")]
    public class UsuarioEstudiante
    {
        [Key]
        public int ID_UsuarioEstudiante { get; set; }

        public int ID_Estudiante { get; set; }

        [StringLength(50)]
        public string Nombre { get; set; }

        [StringLength(50)]
        public string Contraseña { get; set; }

        [StringLength(10)]
        public string Estado { get; set; }

        public virtual Estudiante Estudiante { get; set; }

        public ResponseModel Acceder(string Usuario, string Password)
        {
            var rm = new ResponseModel();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    //Password = HashHelper.MD5(Password);
                    var query = db.UsuarioEstudiante.Where(x => x.Nombre == Usuario)
                                    .Where(x => x.Contraseña == Password)
                                    .Where(x => x.Estado == "A")
                                    .SingleOrDefault();
                    if (query != null)
                    {
                        SessionHelper.AddUserToSession(query.ID_UsuarioEstudiante.ToString());
                        rm.SetResponse(true);
                    }
                    else
                    {
                        rm.SetResponse(false, "Usuario y/o password incorrectos");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return rm;
        }


        //Metodo Listar
        public List<UsuarioEstudiante> Listar() //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<UsuarioEstudiante>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioEstudiante.Include("Estudiante").ToList(); //Debe listar lo que hay en mi Tabla Usuario
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //Metodo Buscar

        public List<UsuarioEstudiante> Buscar(String Criterio) //retorna una lista o colección del objetos
        {
            var obj_usuarios = new List<UsuarioEstudiante>();

            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioEstudiante.Include("Estudiante")
                                    .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj_usuarios;
        }

        //Metodo Obtener

        public UsuarioEstudiante Obtener(int id) //retornar un objeto
        {
            var obj_usuarios = new UsuarioEstudiante();
            try
            {
                using (var db = new BDModeloTaex())
                {
                    obj_usuarios = db.UsuarioEstudiante.Include("Estudiante")
                                    .Where(x => x.ID_UsuarioEstudiante == id)
                                    .SingleOrDefault(); //devuelve un registro
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return obj_usuarios; //Muestra o retorna todos los objetos almacenados
        }

        //metodo guardar
        public void Guardar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {
                    if (this.ID_UsuarioEstudiante > 0)
                    {
                        db.Entry(this).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Entry(this).State = EntityState.Added;
                    }
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //eliminar
        public void Eliminar()
        {
            try
            {
                using (var db = new BDModeloTaex())
                {


                    db.Entry(this).State = EntityState.Deleted;

                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}