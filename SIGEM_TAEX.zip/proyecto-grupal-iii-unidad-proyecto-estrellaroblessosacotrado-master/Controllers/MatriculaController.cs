﻿using SIGEM_TAEX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Filter2;
using System.Net.Mail;

namespace SIGEM_TAEX.Controllers
{
    [Autenticado]
    public class MatriculaController : Controller
    {
        // GET: Matricula
        private Matricula objMatricula = new Matricula();
        private Estudiante objEstudiante = new Estudiante();
        private Taller objTaller = new Taller();

        public ActionResult Index(string Criterio)
        {
            if (Criterio == null || Criterio == "")
            {
                return View(objMatricula.Listar());
            }
            else
            {
                return View(objMatricula.Buscar(Criterio));
            }
        }

        public ActionResult Ver(int id)
        {
            return View(objMatricula.Obtener(id));
        }

        public ActionResult Buscar(string Criterio)
        {
            return View
                (
                Criterio == null || Criterio == "" ? objMatricula.Listar()
                    : objMatricula.Buscar(Criterio)
                );
        }

        private Estudiante objDocente = new Estudiante();
        private Taller objLugar = new Taller();
        private Periodo objHorario = new Periodo();

        public ActionResult AgregarEditar(int id = 0)
        {//
            ViewBag.Docente = objDocente.Listar();
            ViewBag.Docente1 = objLugar.Listar();
            ViewBag.Docente2 = objHorario.Listar();
            //  
            return View(
                id == 0 ? new Matricula()
                        : objMatricula.Obtener(id)
            );
        }

        public ActionResult Guardar(Matricula model)
        {
            if (ModelState.IsValid)
            {
                int est_id = model.ID_Estudiante;
                int taller_id = model.ID_Taller;

                Estudiante dato = objEstudiante.Obtener(est_id);
                string est_nombre = dato.Nombres;
                string est_apellidos = dato.Apellido_Paterno + dato.Apellido_Materno;
                string est_correo = dato.Correo;

                Taller datotaller = objTaller.Obtener(taller_id);
                string taller_nom = datotaller.Nombre;
                string taller_doc = datotaller.Docente.Nombres + datotaller.Docente.Apellido_Paterno + datotaller.Docente.Apellido_Materno;
                string taller_dia = datotaller.Horario.Dia;
                string taller_hora = datotaller.Horario.Hora + " - " + datotaller.Horario.Hora_Fin;
                string taller_lugar = datotaller.Lugar.Direccion;
                string taller_costo = Convert.ToString(model.Costo_Taller);

                model.Guardar();

                try
                {
                    //Variables de Datos (Reemplazar)
                    string correo_estudiante = est_correo;
                    string nombre_estudiante = est_nombre + est_apellidos;
                    string nombre_taller = taller_nom;
                    string nombre_docente = taller_doc;
                    string dia = taller_dia;
                    string hora = taller_hora;
                    string lugar = taller_lugar;
                    string costo = taller_costo;

                    MailMessage correo = new MailMessage();
                    correo.From = new MailAddress("taex.upt@gmail.com"); // El correo electronico que usara nuestra aplicacion MVC para envier correos.
                    correo.To.Add(correo_estudiante); //correo del alumno
                    correo.Subject = "INSCRIPCIÓN EN TALLER EXTRACURRICULAR";
                    correo.Body = @"<html><head>"
                                + "<title>TAEX</title>"
                                + "</head>\n"
                                + "<body>"

                                + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/logo_taex.png?alt=media&token=1e39d56d-1ebf-4bd9-b97c-fde8325119d3\"width=\"100\" height=\"100\"/>"
                                + "<div> <font color=\"#041F85\"> <b>¡FELICITACIONES " + nombre_estudiante + "!</b> </font></div>\n"
                                + "<br>"
                                + "<div> <font color=\"#D89000\"> <i> Te has registrado en el siguiente taller: </i> </font></div>\n"
                                + "<br>"

                                + "<table border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bordercolor=\"#041F85\" >\n" +
                                "\t\t<tr>\n" +
                                "\t\t\t<th>TALLER</th>\n" +
                                "\t\t\t<th>DOCENTE</th>\n" +
                                "\t\t\t<th>DÍA</th>\n" +
                                "\t\t\t<th>HORA</th>\n" +
                                "\t\t\t<th>LUGAR</th>\n" +
                                "\t\t</tr>\n" +
                                "\t\t<tr>\n" +
                                "\t\t\t<td>" + nombre_taller + "</td>\n" +
                                "\t\t\t<td>" + nombre_docente + "</td>\n" +
                                "\t\t\t<td>" + dia + "</td>\n" +
                                "\t\t\t<td>" + hora + "</td>\n" +
                                "\t\t\t<td>" + lugar + "</td>\n" +
                                "\t\t</tr>\n" +
                                "\t\t</table>"

                                + "<br>"
                                + "<div> <font color=\"#D89000\"> <i> El costo del taller es: S/" + costo + "</i> </font></div>\n"

                                + "<br>"

                                + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/LOGO_OBUN.png?alt=media&token=3c82683c-952c-4e6a-8f53-7b2a5d9e0208\" width=\"150\" height=\"80\"/>"
                                + "<img src=\"https://1.bp.blogspot.com/-fiCqijmx7UY/Won9KRnJa0I/AAAAAAAAAII/b6s8IbQxqosNaboSBHLpNH_189pil13ZACLcBGAs/s1600/upt-resultados.jpg\" width=\"200\" height=\"100\"/>"

                                + "</body>"
                                + "</html>";

                    correo.IsBodyHtml = true;
                    correo.Priority = MailPriority.Normal;

                    //Se almacena los archivos adjuntos en una carpeta, creada en el proyecto con anterioridad temporal

                    //String ruta = Server.MapPath("../Temporal");
                    //fichero.SaveAs(ruta + "\\" + fichero.FileName);

                    //Attachment adjunto = new Attachment(ruta + "\\" + fichero.FileName);
                    //correo.Attachments.Add(adjunto);

                    //Configuracion del servidor SMTP *****************************************************

                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 25;
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = true;
                    string sCuentaCorreo = "taex.upt@gmail.com";
                    string sPasswordCorreo = "sharonykatty";
                    smtp.Credentials = new System.Net.NetworkCredential(sCuentaCorreo, sPasswordCorreo);
                    smtp.Send(correo);
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return Redirect("~/Matricula");
            }

            else
            {
                return View("~/View/Matricula/AgregarEditar.cshtml", model);
            }
        }

        public ActionResult Eliminar(int id)
        {
            objMatricula.ID_Matricula = id;
            objMatricula.Eliminar();
            return Redirect("~/Matricula");
        }
    }
}