﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class Perfil2Controller : Controller
    {
        private UsuarioOBUN objdocente = new UsuarioOBUN();
        // GET: Perfil
        public ActionResult Index()
        {
            return View(objdocente.Obtener(SessionHelper.GetUser()));
        }
        public JsonResult Actualizar(UsuarioOBUN model)
        {
            var rm = new ResponseModel();
            //remover los campos que no se van a actualizar
            ModelState.Remove("ID_UsuarioObun");
            ModelState.Remove("ID_Personal");
            ModelState.Remove("Estado");

            if (ModelState.IsValid)
            {
                rm = model.GuardarPerfil();
            }
            rm.href = Url.Content("/Default/Index");
            return Json(rm);
        }
    }
}