﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class PerfilController : Controller
    {
        private Usuariodocente objdocente = new Usuariodocente();
        // GET: Perfil
        public ActionResult Index()
        {
            return View(objdocente.Obtener(SessionHelper.GetUser()));
        }
        public JsonResult Actualizar(Usuariodocente model)
        {
            var rm = new ResponseModel();
            //remover los campos que no se van a actualizar
            ModelState.Remove("ID_UsuarioDocente");
            ModelState.Remove("ID_Docente");
            ModelState.Remove("Estado");

            if (ModelState.IsValid)
            {
                rm = model.GuardarPerfil();
            }
            rm.href = Url.Content("/Default/Index");
            return Json(rm);
        }
    }
}