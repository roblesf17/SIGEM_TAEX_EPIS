﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class UsuarioOBUNController : Controller
    {
        private UsuarioOBUN objUsuarioObun = new UsuarioOBUN();
        // GET: UsuarioOBUN
        public ActionResult Index(string Criterio)
        {
            if (Criterio == null || Criterio == "")
            {
                return View(objUsuarioObun.Listar());
            }
            else
            {
                return View(objUsuarioObun.Buscar(Criterio));
            }
        }

        public ActionResult Ver(int id)
        {
            return View(objUsuarioObun.Obtener(id));
        }

        public ActionResult Buscar(string Criterio)
        {
            return View
                (
                Criterio == null || Criterio == "" ? objUsuarioObun.Listar()
                    : objUsuarioObun.Buscar(Criterio)

                );
        }

        private Personal_OBUN objPersonal_OBUN = new Personal_OBUN();

        public ActionResult AgregarEditar(int id = 0)
        {//
            ViewBag.Docente = objPersonal_OBUN.Listar();
            //  

            return View(
                id == 0 ? new UsuarioOBUN()
                        : objUsuarioObun.Obtener(id)
            );
        }

        public ActionResult Guardar(UsuarioOBUN model)
        {
            if (ModelState.IsValid)
            {
                model.Guardar();
                return Redirect("~/Usuario");
            }

            else
            {
                return View("~/View/UsuarioOBUN/AgregarEditar.cshtml", model);
            }
        }

        public ActionResult Eliminar(int id)
        {
            objUsuarioObun.ID_UsuarioObun = id;
            objUsuarioObun.Eliminar();
            return Redirect("~/Usuario");
        }

    }
}