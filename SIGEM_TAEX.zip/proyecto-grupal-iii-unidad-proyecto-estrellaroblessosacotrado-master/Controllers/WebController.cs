﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.FilterE;
using SIGEM_TAEX.Models;

using System.Net.Mail;

namespace SIGEM_TAEX.Controllers
{
    
    public class WebController : Controller
    {
        // GET: Web
        private Taller objTaller = new Taller();
        private Estudiante objEstudiante = new Estudiante();
        private UsuarioEstudiante objUSUEstudiante = new UsuarioEstudiante();
        private Matricula objMatricula = new Matricula();

        private Nota objnota = new Nota();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Conocenos()
        {
            return View();
        }

        public ActionResult Talleres()
        {
            return View(objTaller.Listar());
        }

        public ActionResult VerTaller(int id)
        {
            return View(objTaller.Obtener(id));
        }

        [Autenticado2]
        public ActionResult Inscribirse(int id)
        {
            ViewBag.Taller = objTaller.Obtener(id);
            ViewBag.UsuEstudiante = objUSUEstudiante.Obtener(SessionHelper.GetUser());

            int guardar = 0;

            return View(
                guardar == 0 ? new Matricula()
                        : objMatricula.Obtener(0)
            );            
        }
        [HttpPost]
        public ActionResult GuardarMatricula(Matricula model, string est_nombre, string est_apellidos, string est_correo, string taller_nom, 
                                                             string taller_doc, string taller_dia, string taller_hora, string taller_lugar, string taller_costo)
        {
            if (ModelState.IsValid)
            {
                model.Guardar();

                try
                {
                    //Variables de Datos (Reemplazar)
                    string correo_estudiante = est_correo;
                    string nombre_estudiante = est_nombre + est_apellidos;
                    string nombre_taller = taller_nom;
                    string nombre_docente = taller_doc;
                    string dia = taller_dia;
                    string hora = taller_hora;
                    string lugar = taller_lugar;
                    string costo = taller_costo;

                    MailMessage correo = new MailMessage();
                    correo.From = new MailAddress("taex.upt@gmail.com"); // El correo electronico que usara nuestra aplicacion MVC para envier correos.
                    correo.To.Add(correo_estudiante); //correo del alumno
                    correo.Subject = "INSCRIPCIÓN EN TALLER EXTRACURRICULAR";
                    correo.Body = @"<html><head>"
                                + "<title>TAEX</title>"
                                + "</head>\n"
                                + "<body>"

                                + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/logo_taex.png?alt=media&token=1e39d56d-1ebf-4bd9-b97c-fde8325119d3\"width=\"100\" height=\"100\"/>"
                                + "<div> <font color=\"#041F85\"> <b>¡FELICITACIONES " + nombre_estudiante + "!</b> </font></div>\n"
                                + "<br>"
                                + "<div> <font color=\"#D89000\"> <i> Te has registrado en el siguiente taller: </i> </font></div>\n"
                                + "<br>"

                                + "<table border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bordercolor=\"#041F85\" >\n" +
                                "\t\t<tr>\n" +
                                "\t\t\t<th>TALLER</th>\n" +
                                "\t\t\t<th>DOCENTE</th>\n" +
                                "\t\t\t<th>DÍA</th>\n" +
                                "\t\t\t<th>HORA</th>\n" +
                                "\t\t\t<th>LUGAR</th>\n" +
                                "\t\t</tr>\n" +
                                "\t\t<tr>\n" +
                                "\t\t\t<td>" + nombre_taller + "</td>\n" +
                                "\t\t\t<td>" + nombre_docente + "</td>\n" +
                                "\t\t\t<td>" + dia + "</td>\n" +
                                "\t\t\t<td>" + hora + "</td>\n" +
                                "\t\t\t<td>" + lugar + "</td>\n" +
                                "\t\t</tr>\n" +
                                "\t\t</table>"

                                + "<br>"
                                + "<div> <font color=\"#D89000\"> <i> El costo del taller es: S/" + costo + "</i> </font></div>\n"

                                + "<br>"

                                + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/LOGO_OBUN.png?alt=media&token=3c82683c-952c-4e6a-8f53-7b2a5d9e0208\" width=\"150\" height=\"80\"/>"
                                + "<img src=\"https://1.bp.blogspot.com/-fiCqijmx7UY/Won9KRnJa0I/AAAAAAAAAII/b6s8IbQxqosNaboSBHLpNH_189pil13ZACLcBGAs/s1600/upt-resultados.jpg\" width=\"200\" height=\"100\"/>"

                                + "</body>"
                                + "</html>";

                    correo.IsBodyHtml = true;
                    correo.Priority = MailPriority.Normal;

                    //Se almacena los archivos adjuntos en una carpeta, creada en el proyecto con anterioridad temporal

                    //String ruta = Server.MapPath("../Temporal");
                    //fichero.SaveAs(ruta + "\\" + fichero.FileName);

                    //Attachment adjunto = new Attachment(ruta + "\\" + fichero.FileName);
                    //correo.Attachments.Add(adjunto);

                    //Configuracion del servidor SMTP *****************************************************

                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 25;
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = true;
                    string sCuentaCorreo = "taex.upt@gmail.com";
                    string sPasswordCorreo = "sharonykatty";
                    smtp.Credentials = new System.Net.NetworkCredential(sCuentaCorreo, sPasswordCorreo);
                    smtp.Send(correo);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return RedirectToAction("FichaInscripcion", "Web", new { @id=model.ID_Matricula});
            }

            else
            {
                return View("~/Web/Incribirse.cshtml", model);
            }
        }

        [Autenticado2]
        public ActionResult FichaInscripcion(int id)
        {
            return View(objMatricula.Obtener(id));
        }

        [Autenticado2]
        public ActionResult PerfilUsuario()
        {
            UsuarioEstudiante dato = objUSUEstudiante.Obtener(SessionHelper.GetUser());
            int est_id = dato.Estudiante.Numero_Identificacion;

            ViewBag.UsuEstudiante = objUSUEstudiante.Obtener(SessionHelper.GetUser());
            ViewBag.Matriculas = objMatricula.BuscarMisMatriculas(est_id);
            ViewBag.Notas = objnota.BuscarNotaEstudiante(est_id);

            return View();
        }


        public void EnviarImagen(string est_nombre, string est_apellidos, string est_correo, string taller_nom,
                                                             string taller_doc, string taller_dia, string taller_hora, string taller_lugar, string taller_costo)
        {
            try
            {
                //Variables de Datos (Reemplazar)
                string correo_estudiante = est_correo;      
                string nombre_estudiante = est_nombre + est_apellidos;
                string nombre_taller = taller_nom;
                string nombre_docente = taller_doc;
                string dia = taller_dia;
                string hora = taller_hora;
                string lugar = taller_lugar;
                string costo = taller_costo;

                MailMessage correo = new MailMessage();
                correo.From = new MailAddress("taex.upt@gmail.com"); // El correo electronico que usara nuestra aplicacion MVC para envier correos.
                correo.To.Add(correo_estudiante); //correo del alumno
                correo.Subject = "INSCRIPCIÓN EN TALLER EXTRACURRICULAR";
                correo.Body = @"<html><head>"
                            + "<title>TAEX</title>"
                            + "</head>\n"
                            + "<body>"

                            + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/logo_taex.png?alt=media&token=1e39d56d-1ebf-4bd9-b97c-fde8325119d3\"width=\"100\" height=\"100\"/>"
                            + "<div> <font color=\"#041F85\"> <b>¡FELICITACIONES " + nombre_estudiante + "!</b> </font></div>\n"
                            + "<br>"
                            + "<div> <font color=\"#D89000\"> <i> Te has registrado en el siguiente taller: </i> </font></div>\n"
                            + "<br>"

                            + "<table border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bordercolor=\"#041F85\" >\n" +
                            "\t\t<tr>\n" +
                            "\t\t\t<th>TALLER</th>\n" +
                            "\t\t\t<th>DOCENTE</th>\n" +
                            "\t\t\t<th>DÍA</th>\n" +
                            "\t\t\t<th>HORA</th>\n" +
                            "\t\t\t<th>LUGAR</th>\n" +
                            "\t\t</tr>\n" +
                            "\t\t<tr>\n" +
                            "\t\t\t<td>" + nombre_taller + "</td>\n" +
                            "\t\t\t<td>" + nombre_docente + "</td>\n" +
                            "\t\t\t<td>" + dia + "</td>\n" +
                            "\t\t\t<td>" + hora + "</td>\n" +
                            "\t\t\t<td>" + lugar + "</td>\n" +
                            "\t\t</tr>\n" +
                            "\t\t</table>"

                            + "<br>"
                            + "<div> <font color=\"#D89000\"> <i> El costo del taller es: S/" + costo + "</i> </font></div>\n"

                            + "<br>"

                            + "<img src=\"https://firebasestorage.googleapis.com/v0/b/taex-cd0ee.appspot.com/o/LOGO_OBUN.png?alt=media&token=3c82683c-952c-4e6a-8f53-7b2a5d9e0208\" width=\"150\" height=\"80\"/>"
                            + "<img src=\"https://1.bp.blogspot.com/-fiCqijmx7UY/Won9KRnJa0I/AAAAAAAAAII/b6s8IbQxqosNaboSBHLpNH_189pil13ZACLcBGAs/s1600/upt-resultados.jpg\" width=\"200\" height=\"100\"/>"

                            + "</body>"
                            + "</html>";

                correo.IsBodyHtml = true;
                correo.Priority = MailPriority.Normal;

                //Se almacena los archivos adjuntos en una carpeta, creada en el proyecto con anterioridad temporal

                //String ruta = Server.MapPath("../Temporal");
                //fichero.SaveAs(ruta + "\\" + fichero.FileName);

                //Attachment adjunto = new Attachment(ruta + "\\" + fichero.FileName);
                //correo.Attachments.Add(adjunto);

                //Configuracion del servidor SMTP *****************************************************

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 25;
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = true;
                string sCuentaCorreo = "taex.upt@gmail.com";
                string sPasswordCorreo = "sharonykatty";
                smtp.Credentials = new System.Net.NetworkCredential(sCuentaCorreo, sPasswordCorreo);
                smtp.Send(correo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}