﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class UsuarioDocenteController : Controller
    {
        private Usuariodocente objUsuarioDocente = new Usuariodocente();
        // GET: UsuarioDocente
        public ActionResult Index(string Criterio)
        {
            if (Criterio == null || Criterio == "")
            {
                return View(objUsuarioDocente.Listar());
            }
            else
            {
                return View(objUsuarioDocente.Buscar(Criterio));
            }
        }

        public ActionResult Ver(int id)
        {
            return View(objUsuarioDocente.Obtener(id));
        }
        public ActionResult Buscar(string Criterio)
        {
            return View
                (
                Criterio == null || Criterio == "" ? objUsuarioDocente.Listar()
                    : objUsuarioDocente.Buscar(Criterio)

                );
        }
        private Docente objDocente = new Docente();

        public ActionResult AgregarEditar(int id = 0)
        {//
            ViewBag.Docente = objDocente.Listar();
            //  

            return View(
                id == 0 ? new Usuariodocente()
                        : objUsuarioDocente.Obtener(id)
            );
        }


        public ActionResult Guardar(Usuariodocente model)
        {
            if (ModelState.IsValid)
            {
                model.Guardar();
                return Redirect("~/Usuario");
            }

            else
            {
                return View("~/View/UsuarioDocente/AgregarEditar.cshtml", model);
            }
        }

        public ActionResult Eliminar(int id)
        {
            objUsuarioDocente.ID_UsuarioDocente = id;
            objUsuarioDocente.Eliminar();
            return Redirect("~/Usuario");
        }



    }
}