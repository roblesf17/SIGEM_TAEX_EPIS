﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Filters;
using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class LoginEstController : Controller
    {
        private UsuarioEstudiante objusuario = new UsuarioEstudiante();
        // GET: LoginEstudiante
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult Acceder(string usuario, string password)
        {
            var rm = objusuario.Acceder(usuario, password);
            if (rm.response)
            {
                rm.href = Url.Content("~/Web/Index");
            }
            return Json(rm);
        }
        public ActionResult Logout()
        {
            SessionHelper.DestroyUserSession();
            return Redirect("~/Web/Index");
        }

        public ActionResult Registrarte()
        {
            return View();
        }
    }
}