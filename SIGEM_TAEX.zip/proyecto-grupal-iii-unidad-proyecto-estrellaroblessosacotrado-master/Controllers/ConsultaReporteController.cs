﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class ConsultaReporteController : Controller
    {
        // GET: ConsultaReporte
        private Nota objEstudiante = new Nota();
        private Taller objtaller = new Taller();
        private Estudiante objEstudiante2 = new Estudiante();
        private Matricula objMatricula = new Matricula();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Consulta(string codigo, string taller)
        {
            if (codigo == null || codigo == "" || taller == null || taller == "")
            {
                return View(objEstudiante.Listar2());
            }
            else
            {
                return View(objEstudiante.BuscarNota(Convert.ToInt32(codigo), taller));
            }
        }
        public ActionResult Reportes(string periodo)
        {
            ViewBag.Estudiante = objEstudiante2.Listar();
            ViewBag.CantTaller = objtaller.ObtenerCategoria1Taller();

            ViewBag.MatriculaSeC1 = objMatricula.BuscarPeriodoC1(periodo);
            return View();
        }

        public JsonResult BuscarTaller(string term)
        {
            using (BDModeloTaex db = new BDModeloTaex())
            {
                var resultado = db.Taller.Where(x => x.Nombre.Contains(term))
                    .Select(x => x.Nombre).ToList();
                return Json(resultado, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult BuscarPeriodo(string term)
        {
            using (BDModeloTaex db = new BDModeloTaex())
            {
                var resultado = db.Periodo.Where(x => x.Nombre_Periodo.Contains(term))
                    .Select(x => x.Nombre_Periodo).ToList();
                return Json(resultado, JsonRequestBehavior.AllowGet);
            }
        }
    }
}