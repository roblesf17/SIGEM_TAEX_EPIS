﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Filter2;
using SIGEM_TAEX.Models;
using CaptchaMvc.HtmlHelpers;

using System.Net;
using Newtonsoft.Json;


namespace SIGEM_TAEX.Controllers
{
    public class Login2Controller : Controller
    {
        private UsuarioOBUN objusuario = new UsuarioOBUN();
        private Estudiante objEstudiante = new Estudiante();
        // GET: Login2


        public ActionResult Index()
        {
            return View();
        }
        public JsonResult Acceder(string usuario, string password)
        {
            var rm = objusuario.Acceder(usuario, password);
            if (rm.response)
            {
                if (!this.IsCaptchaValid(""))
                {
                    ViewBag.mensaje = "Captcha no es válido";
                    rm.href = Url.Content("~/Login2/Index");
                }
                else
                {
                    rm.href = Url.Content("~/Default/Index");
                }
                
            }
            return Json(rm);
        }
        public ActionResult Logout()
        {
            SessionHelper.DestroyUserSession();
            return Redirect("~/Login2");
        }

        public ActionResult Registrarte()
        {
            int nuevo = 0;
            return View(
                nuevo == 0 ? new Estudiante()
                        : objEstudiante.Obtener(nuevo)
            );
        }

        public static string primero_nombre_temporal = "";
        public static string segundo_nombre_temporal = "";
        public static string apellido_paterno_temporal = "";
        public static string apellido_materno_temporal = "";
        public static string dni_docente_temporal = "";

        public ActionResult Guardar(Estudiante model, UsuarioEstudiante modelUsu, string submitButton, string usu_nombre, string usu_contrasena, string usu_estado)
        {
            switch (submitButton)
            {
                case "Consultar en RENIEC":

                    if (model.Tipo_Identificacion.Equals("DNI"))
                    {
                        //
                        string dni = Convert.ToString(model.Numero_Identificacion);

                        if (dni != null && !dni.Equals(""))
                        {
                            String url = "https://quertium.com/api/v1/reniec/dni/" + dni + "?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.MTM3NA.VXfwWGycEWoyGTtzUb3YSNI0688GiCIY6FTXETFEO_c";

                            WebClient wc = new WebClient();
                            var datos = wc.DownloadString(url);
                            // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
                            var rs = JsonConvert.DeserializeObject<Root>(datos);
                            primero_nombre_temporal = Convert.ToString(rs.primerNombre);
                            segundo_nombre_temporal = Convert.ToString(rs.segundoNombre);
                            apellido_paterno_temporal = Convert.ToString(rs.apellidoPaterno);
                            apellido_materno_temporal = Convert.ToString(rs.apellidoMaterno);

                            dni_docente_temporal = dni;
                        }
                        //
                    }

                    return RedirectToAction("Registrarte");

                case "Guardar Datos":
                    if (ModelState.IsValid)
                    {
                        model.Guardar();
                        var est = model;
                        int codigo = est.ID_Estudiante;

                        var usu = modelUsu;
                        usu.ID_Estudiante = codigo;
                        usu.Nombre = usu_nombre;
                        usu.Contraseña = usu_contrasena;
                        usu.Estado = usu_estado;
                        usu.Guardar();
                        return Redirect("~/LoginEst/Index");
                    }

                    else
                    {
                        return View("~/View/Login2/Registrarte.cshtml", model);
                    }

                ///
                case "Limpiar Consulta":
                    primero_nombre_temporal = "";
                    segundo_nombre_temporal = "";
                    apellido_paterno_temporal = "";
                    apellido_materno_temporal = "";
                    dni_docente_temporal = "";

                    return RedirectToAction("Registrarte");

            }

            return View();
        }
    }
}