﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class UsuarioEstudianteController : Controller
    {
        private UsuarioEstudiante objUsuarioEstudiante = new UsuarioEstudiante();
        // GET: UsuarioEstudiante
        public ActionResult Index(string Criterio)
        {
            if (Criterio == null || Criterio == "")
            {
                return View(objUsuarioEstudiante.Listar());
            }
            else
            {
                return View(objUsuarioEstudiante.Buscar(Criterio));
            }
        }

        public ActionResult Ver(int id)
        {
            return View(objUsuarioEstudiante.Obtener(id));
        }

        public ActionResult Buscar(string Criterio)
        {
            return View
                (
                Criterio == null || Criterio == "" ? objUsuarioEstudiante.Listar()
                    : objUsuarioEstudiante.Buscar(Criterio)

                );
        }

        private Estudiante objEstudiante = new Estudiante();

        public ActionResult AgregarEditar(int id = 0)
        {//
            ViewBag.Docente = objEstudiante.Listar();
            //  

            return View(
                id == 0 ? new UsuarioEstudiante()
                        : objUsuarioEstudiante.Obtener(id)
            );
        }

        public ActionResult Guardar(UsuarioEstudiante model)
        {
            if (ModelState.IsValid)
            {
                model.Guardar();
                return Redirect("~/Usuario");
            }

            else
            {
                return View("~/View/UsuarioEstudiante/AgregarEditar.cshtml", model);
            }
        }

        public ActionResult Eliminar(int id)
        {
            objUsuarioEstudiante.ID_UsuarioEstudiante = id;
            objUsuarioEstudiante.Eliminar();
            return Redirect("~/Usuario");
        }

    }











}