﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Models;
using SIGEM_TAEX.Filters;
using CaptchaMvc.HtmlHelpers;

namespace SIGEM_TAEX.Controllers
{
    public class LoginDocenteController : Controller
    {
        private Usuariodocente objusuario = new Usuariodocente();
        // GET: LoginDocente
        
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Acceder(string usuario, string password)
        {
            var rm = objusuario.Acceder(usuario, password);
            if (rm.response)
            {
                if (!this.IsCaptchaValid(""))
                {
                    ViewBag.mensaje = "Captcha no es válido";
                    rm.href = Url.Content("~/LoginDocente/Index");
                }
                else
                {
                    rm.href = Url.Content("~/Default/IndexDocente");
                }
            }
            return Json(rm);
        }
        public ActionResult Logout()
        {
            SessionHelper.DestroyUserSession();
            return Redirect("~/LoginDocente");
        }

        public ActionResult Registrarte()
        {
            return View();
        }
    }
}