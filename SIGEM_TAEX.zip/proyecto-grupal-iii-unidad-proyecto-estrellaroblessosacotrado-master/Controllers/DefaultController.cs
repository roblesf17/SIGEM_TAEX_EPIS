﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SIGEM_TAEX.Models;

namespace SIGEM_TAEX.Controllers
{
    public class DefaultController : Controller
    {

        // GET: Default

        private Matricula objMatricula = new Matricula();
        private Estudiante objEstudiante = new Estudiante();
        private Taller objTaller = new Taller();
        private UsuarioOBUN objObun = new UsuarioOBUN();
        public ActionResult Index()
        {
            ViewBag.Estudiante = objEstudiante.Listar();
            ViewBag.Taller = objTaller.Listar();
            ViewBag.Obun = objObun.Listar();
            ViewBag.ReMa = objMatricula.Listar2();
            return View(objMatricula.ObtenerMatriculaSemestre());
        }

        public ActionResult PruebaLista(IEnumerable<int> results)
        {
            return View();
        }

        public ActionResult IndexDocente()
        {
            return View();
        }
    }

}